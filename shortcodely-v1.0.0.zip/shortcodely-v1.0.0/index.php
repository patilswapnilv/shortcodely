<?php
/**
 * Silence is golden.
 *
 * @package shortcodely
 */
